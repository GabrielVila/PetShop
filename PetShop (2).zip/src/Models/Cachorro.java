package Models;

public class Cachorro extends Animais {
}
