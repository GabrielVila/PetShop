import Models.*;
public class PetShop {
    public static void main(String[] args) {
        String cnpj;
        Endereco endereco;



        //Metódos
//        ProdutoServico.ResponseVSO higienizar (Cliente cliente, List < Registro.Animais > animais, Higiene higiene, String observacao){
//
//        }
//        ProdutoServico.ResponseVSO atendimentoClinico (Cliente cliente, List < Registro.Animais > animais, String observacao){
//
//        }
//        ProdutoServico.ResponseVSO vacinacao (Cliente cliente, List < Registro.Animais > animais, List < Enums.Vacinas > vacinas, String observacao){
//        }
//        void verAlimentos () {
//
//        }
//        void verRemedios () {
//
//        }
    }
}