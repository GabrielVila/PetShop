package Enums;

public enum Servicos {
    HIGIENIZAR,
    ATENDIMENTO_CLINICO,
    VACINACAO;
}
