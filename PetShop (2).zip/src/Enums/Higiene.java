package Enums;

public enum Higiene {
    BANHO,
    TOSA,
    BANHO_E_TOSA;
}
