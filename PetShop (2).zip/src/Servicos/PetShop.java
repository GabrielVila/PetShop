package Servicos;

import Enums.EstadoAnimal;
import Enums.Higiene;
import Enums.Servicos;
import Enums.Vacinas;
import Models.Animais;
import Models.Clientes;
import Models.Endereco;
import VO.ResponseVO;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class PetShop {
    //Atributos
    final int HIGIENIZAR = 1;
    final int ATENDIMENTO = 2;
    final int VACINA = 3;
    private String cnpj;
    private Endereco endereco;

    static List<Alimentos> alimentoList = criarListaAlimentos();
    static List<Remedio> remedioList = criarListaRemedios();

    //Metódos

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public static List<Remedio> criarListaRemedios() {
        Remedio remedio = new Remedio(1, "Gaviz", new BigDecimal("20"));
        Remedio remedio2 = new Remedio(2, "Dipirona", new BigDecimal("10"));
        Remedio remedio3 = new Remedio(3, "Floral", new BigDecimal("35"));
        Remedio remedio4 = new Remedio(4, "Vitamina", new BigDecimal("33"));
        return Arrays.asList(remedio, remedio2, remedio3, remedio4);

    }

    public static List<Alimentos> criarListaAlimentos() {
        Alimentos alimento = new Alimentos(5, "Ração Umida", new BigDecimal("10"));
        Alimentos alimento2 = new Alimentos(6, "Ração Seca", new BigDecimal("100"));
        Alimentos alimento3 = new Alimentos(7, "Biscoito", new BigDecimal("35"));
        Alimentos alimento4 = new Alimentos(8, "Ossinho", new BigDecimal("6"));
        return Arrays.asList(alimento, alimento2, alimento3, alimento4);

    }


    public ResponseVO higienizar(Clientes cliente, List<Animais> animais, Higiene higiene, String observacao) {
        ResponseVO response = new ResponseVO();
        for (int i = 0; i < animais.size(); i++) {
            if (higiene.equals(Higiene.BANHO)) {
                response.setValor(BigDecimal.valueOf(25));
                animais.get(i).setEstado(EstadoAnimal.LIMPO);
            } else if (higiene.equals(Higiene.TOSA)) {
                response.setValor(BigDecimal.valueOf(45));
                animais.get(i).setEstado(EstadoAnimal.TOSADO);
            } else if (higiene.equals(Higiene.BANHO_E_TOSA)) {
                response.setValor(BigDecimal.valueOf(65));
                animais.get(i).setEstado(EstadoAnimal.LIMPO_E_TOSADO);
            }
        }
        BigDecimal x = new BigDecimal(animais.size());
        response.setValor(response.getValor().multiply(x));
        response.setId(HIGIENIZAR);
        response.setClientes(cliente);
        response.setServicos(Servicos.HIGIENIZAR);
        return response;
    }

    public ResponseVO atendimentoClinico(Clientes cliente, List<Animais> animais, String observacao) {
        ResponseVO response = new ResponseVO();
        EsquemaVacinal esquemaVacinal = new EsquemaVacinal();
        for (int i = 0; i < animais.size(); i++) {
            Random random = new Random();
            int aleatorio = random.nextInt(4);
            switch (aleatorio + 1) {
                case 1:
                    animais.get(i).setObservacoes(observacao = String.valueOf(Vacinas.VACINA_1));
                    break;
                case 2:
                    animais.get(i).setObservacoes(observacao = String.valueOf(Vacinas.VACINA_2));
                    break;
                case 3:
                    animais.get(i).setObservacoes(observacao = String.valueOf(Vacinas.VACINA_3));
                    break;
                case 4:
                    animais.get(i).setObservacoes(observacao = String.valueOf(Vacinas.VACINA_4));
                    break;
                case 5:
                    animais.get(i).setObservacoes(observacao = String.valueOf(Vacinas.VACINA_5));
                    break;
            }
            animais.get(i).setEstado(EstadoAnimal.NORMAL);
        }
        response.setId(ATENDIMENTO);
        response.setClientes(cliente);
        response.setValor(BigDecimal.valueOf(110));
        response.setServicos(Servicos.ATENDIMENTO_CLINICO);
        return response;
    }


    public ResponseVO vacinacao(Clientes cliente, List<Animais> animais, List<Vacinas> vacinas, String observacao) {
        ResponseVO response = new ResponseVO();
        EsquemaVacinal esquemaVacinal = new EsquemaVacinal();
        for (int i = 0; i < animais.size(); i++) {
            for (int j=0; i<vacinas.size();j++) {
                if(vacinas.contains(observacao)){
                    System.out.println("Pet " + i + " já tomou a vacina " + observacao);
                    break;
                } else {
                    animais.get(i).getVacinas().add(new EsquemaVacinal(LocalDate.parse("2023-04-23"), vacinas.get(i), "Vacina Tomada"));
                    break;
                }
            }
        }
        response.setId(VACINA);
        response.setClientes(cliente);
        response.setValor(BigDecimal.valueOf(40));
        response.setServicos(Servicos.VACINACAO);


        return response;
    }

    public void verAlimentos() {
        alimentoList.forEach(alimentos -> System.out.println(alimentos));
    }

    public void verRemedios() {
        remedioList.forEach(remedio -> System.out.println(remedio));
    }

    void pagamento() {


    }


}