package Enums;

public enum Cargo {
    VETERINARIO,
    ESTAGIARIO,
    TOSADOR,
    BANHISTA,
    RECEPCIONISTA,
    AUXILIAR_GERAL
}
