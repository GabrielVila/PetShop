package VO;

import Enums.EstadoAnimal;
import Enums.Higiene;
import Enums.Porte;
import Enums.Vacinas;
import Models.Animais;
import Models.Cachorro;
import Models.Clientes;
import Models.Gato;
import Servicos.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        //Construtor
        //Crie o objeto PetShop
        PetShop petShop = new PetShop();
        Pagamento pagamento = new Pagamento();

        Clientes cliente = new Clientes();
        Clientes cliente2 = new Clientes();
        Clientes cliente3 = new Clientes();

        Cachorro cachorro = new Cachorro();
        Cachorro cachorro1 = new Cachorro();
        Gato gato = new Gato();
        Gato gato2 = new Gato();
        Gato gato3 = new Gato();

        EsquemaVacinal esquemaVacinal = new EsquemaVacinal();
        EsquemaVacinal esquemaVacinal2 = new EsquemaVacinal();
        EsquemaVacinal esquemaVacinal3 = new EsquemaVacinal();

        List<Animais> animais = new ArrayList<>();
        List<Animais> animais2 = new ArrayList<>();
        List<Animais> animais3 = new ArrayList<>();

        List<Vacinas> vacinas = new ArrayList<>();
        List<Vacinas> vacinas2 = new ArrayList<>();
        List<Vacinas> vacinas3 = new ArrayList<>();

        List<String> alimentosList = new ArrayList<>();
        List<String> alimentosList2 = new ArrayList<>();
        List<String> alimentosList3 = new ArrayList<>();

        List<String> remedioList = new ArrayList<>();
        List<String> remedioList2 = new ArrayList<>();
        List<String> remedioList3 = new ArrayList<>();

        List<Integer> id = new ArrayList<>();
        List<Integer> id2 = new ArrayList<>();
        List<Integer> id3 = new ArrayList<>();

        //cliente1 - 1 animal
        System.out.println("Cliente 1 - Cão");
        cliente.setId(1);
        cliente.setNome("Fran");
        cachorro.setNome("Mike");
        cachorro.setNascimento(LocalDate.parse("2018-04-23"));
        cachorro.setPorte(Porte.PEQUENO);
        cachorro.setPeso(9.5);
        cachorro.setEstado(EstadoAnimal.NORMAL);
        cachorro.setObservacoes("");
        animais.add(cachorro);
        cliente.setPet(animais);

        ResponseVO response_higienizar = petShop.higienizar(cliente, animais, Higiene.BANHO, null);
        System.out.println(response_higienizar);


        ResponseVO response_atendimentoClinico = petShop.atendimentoClinico(cliente, animais, cachorro.getObservacoes());
        System.out.println(response_atendimentoClinico);


        vacinas.add(Vacinas.valueOf(cachorro.getObservacoes()));
        System.out.println(vacinas);

        ResponseVO response_vacinacao = petShop.vacinacao(cliente, animais, vacinas, cachorro.getObservacoes());
        System.out.println(response_vacinacao);
        System.out.println("\n");

        alimentosList.add("Ração Umida");
        remedioList.add("Dipirona");

        System.out.println(alimentosList);
        System.out.println(remedioList);

        ResponseVO response_conta = pagamento.conta(id, vacinas, remedioList ,alimentosList);
        System.out.println(response_conta);
        System.out.println("\n");



        //cliente2 - 2 animais
        System.out.println("Cliente 2 - Gato e Gato");
        cliente2.setId(2);
        cliente2.setNome("Thalles");

        gato.setNome("Videl");
        gato.setNascimento(LocalDate.parse("2020-08-03"));
        gato.setPorte(Porte.PEQUENO);
        gato.setPeso(3.5);
        gato.setEstado(EstadoAnimal.SUJO);
        gato.setObservacoes(" ");

        gato2.setNome("Garfield");
        gato2.setNascimento(LocalDate.parse("2019-01-03"));
        gato2.setPorte(Porte.PEQUENO);
        gato2.setPeso(5.5);
        gato2.setEstado(EstadoAnimal.SUJO);
        gato2.setObservacoes(" ");

        animais2.add(gato);
        animais2.add(gato2);
        cliente2.setPet(animais2);

        ResponseVO response_higienizar2 = petShop.higienizar(cliente2, animais2, Higiene.BANHO_E_TOSA, "Higienização");
        System.out.println(response_higienizar2);

        ResponseVO response_atendimentoClinico2 = petShop.atendimentoClinico(cliente2, animais2, "Atendimento Clinico");
        System.out.println(response_atendimentoClinico2);

        //Adicionar as observações do Atendimento na lista de 'Vacina' solicitadas
        for (int i = 0; i < animais2.size(); i++) {
            vacinas2.add(Vacinas.valueOf(animais2.get(i).getObservacoes()));
            System.out.println(vacinas2);
        }

        ResponseVO response_vacinacao2 = petShop.vacinacao(cliente2, animais2, vacinas2, "Vacinação");
        System.out.println(response_vacinacao2);

        alimentosList2.add("Ração Umida");
        alimentosList2.add("Ossinho");
        alimentosList2.add("Biscoito");
        remedioList2.add("Dipirona");
        remedioList2.add("Floral");
        System.out.println(alimentosList2);
        System.out.println(remedioList2);

        System.out.println("\n");

        ResponseVO response_conta2 = pagamento.conta(id2, vacinas2, remedioList2 ,alimentosList2);
        System.out.println(response_conta2);

        System.out.println("\n");



        //cliente3 - 2 animais
        System.out.println("Cliente 3 - Cão e Gato");
        cliente3.setId(3);
        cliente3.setNome("Yuri");

        cachorro1.setNome("Ice");
        cachorro1.setNascimento(LocalDate.parse("2017-01-13"));
        cachorro1.setPorte(Porte.MEDIO);
        cachorro1.setPeso(10.5);
        cachorro1.setEstado(EstadoAnimal.SUJO);
        cachorro1.setObservacoes(" ");

        gato3.setNome("Frajola");
        gato3.setNascimento(LocalDate.parse("2017-01-13"));
        gato3.setPorte(Porte.PEQUENO);
        gato3.setPeso(2.5);
        gato3.setEstado(EstadoAnimal.NORMAL);
        gato3.setObservacoes(" ");

        animais3.add(cachorro1);
        animais3.add(gato3);
        cliente3.setPet(animais3);

        ResponseVO response_higienizar3 = petShop.higienizar(cliente3, animais3, Higiene.BANHO_E_TOSA, "Higienização");
        System.out.println(response_higienizar3);

        ResponseVO response_atendimentoClinico3 = petShop.atendimentoClinico(cliente3, animais3, "Atendimento Clinico");
        System.out.println(response_atendimentoClinico3);

        //Adicionar as observações do Atendimento na lista de 'Vacina' solicitadas
        for (int i = 0; i < animais3.size(); i++) {
            vacinas3.add(Vacinas.valueOf(animais3.get(i).getObservacoes()));
            System.out.println(vacinas3);
        }

        ResponseVO response_vacinacao3 = petShop.vacinacao(cliente3, animais3, vacinas3, "Vacinação");
        System.out.println(response_vacinacao3);

        alimentosList3.add("Ração Umida");
        alimentosList3.add("Ossinho");
        alimentosList3.add("Biscoito");
        remedioList3.add("Dipirona");
        remedioList3.add("Dipirona");
        remedioList3.add("Floral");
        System.out.println(alimentosList3);
        System.out.println(remedioList3);

        System.out.println("\n");

        ResponseVO response_conta3 = pagamento.conta(id3, vacinas3, remedioList3 ,alimentosList3);
        System.out.println(response_conta3);


    }
}


