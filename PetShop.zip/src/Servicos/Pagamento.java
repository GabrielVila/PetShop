package Servicos;

import Enums.Vacinas;
import VO.ResponseVO;

import java.util.ArrayList;
import java.util.List;

public  class Pagamento {

    List list = new ArrayList();
    private int id;



    public List getList() {
        return list;
    }

    public void setList(List list) {
        this.list = list;
    }

    public ResponseVO conta(List<Integer> id, List<Vacinas> vacinas, List<String> remedioList, List<String> alimentosList) {
        ResponseVO response = new ResponseVO();

        double conta = 0;
        conta += (vacinas.size() * 55);


        for (int i = 0; i < remedioList.size(); i++) {
            if (remedioList.get(i).contains("Gaviz")) {
                conta += 20;
                id.add(1);
            } else if (remedioList.get(i).contains("Dipirona")) {
                conta += 10;
                id.add(2);
            } else if (remedioList.get(i).contains("Floral")) {
                conta += 35;
                id.add(3);
            } else if (remedioList.get(i).contains("Vitamina")) {
                conta += 33;
                id.add(4);
            }
        }

        for (int i = 0; i < alimentosList.size(); i++) {
            if (alimentosList.get(i).contains("Ração Umida")) {
                conta += 10;
                id.add(5);
            } else if (alimentosList.get(i).contains("Ração Seca")) {
                conta += 100;
                id.add(6);
            } else if (alimentosList.get(i).contains("Biscoito")) {
                conta += 35;
                id.add(7);
            } else if (alimentosList.get(i).contains("Ossinho")) {
                conta += 6;
                id.add(8);
            }
        }



        System.out.println("Ids dos serviços:" + id +"\n" + "| Alimentos " +
                alimentosList +"\n"+ "| Remedios " + remedioList + "\n"+ "| TOTAL A PAGAR: R$" + conta);

        return null;
    }
}
